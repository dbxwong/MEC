function xdot_nonlin = xdot_nonlin(t,x)
% this function contains the nonlinear closed loop dynamics of the cart 
% pendulum in 16-642 PS2 problem 2.  
  A = [0 0 1 0; 0 0 0 1; 0 1 -3 0; 0 2 -3 0];
  B = [0; 0; 1; 1];

  %R = 10
  %Q = diag([1 5 1 5]);
  %[K,S,E] = lqr(A,B,Q,R)                                     
  K = [-0.3162   10.2723   -6.7857    9.2183];

  u = -K*x;

  alpha = 1;
  beta = 1;
  gamma = 2;
  D = 1;
  mu = 3;
%  xdtmp = [alpha beta*cos(x(2)); beta*cos(x(2)) gamma]*([u; 0] - [mu -beta*x(4)*sin(x(2)); 0 0]*[x(3); x(4)] - [0; -D*sin(x(2))]);
  xdtmp = inv([gamma -beta*cos(x(2)); -beta*cos(x(2)) alpha])*([u; 0] - [mu beta*x(4)*sin(x(2)); 0 0]*[x(3); x(4)] - [0; -D*sin(x(2))]);

  xdot_nonlin = [x(3);
                 x(4);
                 xdtmp(1);
                 xdtmp(2)];

end

