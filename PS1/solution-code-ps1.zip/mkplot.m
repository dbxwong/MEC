function mkplot(t,x,titlename,filename)

figure
plot(t,x(1,:),'b-','LineWidth',3);
hold on
plot(t,x(2,:),'g--','LineWidth',3);
plot(t,x(3,:),'r-.','LineWidth',3);
plot(t,x(4,:),'k:','LineWidth',3);
grid on
xlabel('Time (s)');
ylabel('State value');
title(titlename);
legend('x_1 = x_c','x_2 = \phi','x_3 = x_c vel','x_4 = \phi vel');

saveas(gcf,[filename '.eps'],'epsc');

end

