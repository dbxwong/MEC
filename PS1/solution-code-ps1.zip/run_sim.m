function [t,x] = sim(x,xdotfn,tf)

% This function uses fixed timestep fourth-order Runga-Kutta to simulate
% the dynamics of the function defines in xdotfn.

% set timestep
T = 0.01;

t = 0; %start time
if nargin < 3
  tf = 30;
end

num_steps = ceil(tf/T);

for i = 1:num_steps
    k1 = feval(xdotfn,t(i),x(:,i))*T;
    k2 = feval(xdotfn,t(i),x(:,i)+k1/2)*T;
    k3 = feval(xdotfn,t(i),x(:,i)+k2/2)*T;
    k4 = feval(xdotfn,t(i),x(:,i)+k3)*T;
    x(:,i+1) = x(:,i) + (k1 + 2*k2 + 2*k3 + k4)/6;

    t(i+1) = t(i) + T;
end



