function xdot_lin = xdot_lin(t,x)
% this function contains the linearized closed loop dynamics of the cart 
% pendulum in 16-642 PS2 problem 2.

  A = [0 0 1 0; 0 0 0 1; 0 1 -3 0; 0 2 -3 0];
  B = [0; 0; 1; 1];

  %R = 10
  %Q = diag([1 5 1 5]);
  %[K,S,E] = lqr(A,B,Q,R)                                     
  K = [-0.3162   10.2723   -6.7857    9.2183];

  u = -K*x;
  xdot_lin = A*x+B*u;

end

