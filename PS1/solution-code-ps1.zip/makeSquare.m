clear

T = 50;
mag = 20;

yd = [0 mag mag -mag -mag mag mag -mag -mag mag]
t = [0 0 T T 2*T 2*T 3*T 3*T 4*T 4*T]

close all
h = plot(t,yd)
axis([0 200 -1.2*mag, 1.2*mag]);
set(h,'LineWidth', 5)
xlabel('time (s)')
ylabel('desired input (in)')
title('reference input for tracking controller')
grid
