function xdot_nonlin = xdot_nonlin(t,x)
% this function contains the nonlinear closed loop dynamics of the cart 
% pendulum in 16-642 PS1.  
  A = [0 0 1 0; 0 0 0 1; 0 1 -3 0; 0 2 -3 0];
  B = [0; 0; 1; 1];
  C = [39.37, 0, 0, 0];
%   R = 1
%   Q = diag([1 5 1 5]);
%   [K,S,E] = lqr(A,B,Q,R) 
% original K:
K = [   -0.3162   10.2723   -6.7857    9.2183 ];
% better tracking K
%K = [-1.0000   12.9153   -8.6419   11.8733];
  
  % compute desired output at this time step
  mag = 20;
  T = 50;
  if ( mod(t,2*T) < T)
      yd = mag;
  else 
      yd = -mag;
  end
  
  % compute feedforward term
  v = -inv(C*inv(A-B*K)*B)*yd;
  
  % combine feedforward and feedback
  u = v-K*x;

  alpha = 1;
  beta = 1;
  gamma = 2;
  D = 1;
  mu = 3;
%  xdtmp = [alpha beta*cos(x(2)); beta*cos(x(2)) gamma]*([u; 0] - [mu -beta*x(4)*sin(x(2)); 0 0]*[x(3); x(4)] - [0; -D*sin(x(2))]);
  xdtmp = inv([gamma -beta*cos(x(2)); -beta*cos(x(2)) alpha])*([u; 0] - [mu beta*x(4)*sin(x(2)); 0 0]*[x(3); x(4)] - [0; -D*sin(x(2))]);

  xdot_nonlin = [x(3);
                 x(4);
                 xdtmp(1);
                 xdtmp(2)];

end

